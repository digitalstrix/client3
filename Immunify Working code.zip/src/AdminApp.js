import React from "react";
import { createMuiTheme, ThemeProvider } from "@material-ui/core/styles";
import { createTheme } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import PersistentDrawerLeft from "./common/components/Drawer";
import PrivateRoute from "./common/components/PrivateRoute";

import DashboardPage from "./features/Admin/DashboardPage/DashboardPage";
import VaccineListPage from "./features/Admin/VaccineListPage/VaccineListPage";
import VaccinationShedulesPage from "./features/Admin/VaccinationShedulesPage/VaccinationShedulesPage";
import VaccinationCentersPage from "./features/Admin/VaccinationCentersPage/VaccinationCentersPage";
import UserManagementPage from "./features/Admin/UserManagementPage";
import ManageTemplates from "./features/Admin/ManageTemplates/ManageTemplates";
import VacCenterCards from "./features/Admin/ManageCards/VacCenterCards/VacCenterCards";
import VendorCardRequests from "./features/Admin/ManageCards/VendorCardRequests/VendorCardRequests";
import ReportsPage from "./features/Admin/ReportsPage/ReportsPage";
import DoctorApprovalPage from "./features/Admin/Operations/DoctorApprovalPage";
import DoctorSettlementsPage from "./features/Admin/Finance/DoctorSettlementsPage";
import DoctorListPage from "./features/Admin/Operations/DoctorListPage";
import AddNewDoc from "./features/Admin/Operations/DoctorListPage/NewDoc";
import EditDoc from "./features/Admin/Operations/DoctorListPage/EditDoc";
import ConsultationTiming from "./features/Admin/Operations/ConsultationTiming";
import UserEngagement from "./features/Admin/Operations/UserEngagement";

import { PORTAL_TYPE_IMM } from "./constants/commonConstants";
import Tradenamelistpage from "./features/Admin/Tradenames/TradenameListPage/TradenameListPage";
import ApproveTradename from "./features/Admin/Tradenames/ApproveTradename";

export default function AdminApp() {
  const theme = React.useMemo(
    () =>
      createTheme({
        palette: {
          primary: {
            main: "#443266",
          },
          secondary: {
            main: "#530970",
          },
        },
      }),
    []
  );

  return (
    <Router>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Switch>
          <PersistentDrawerLeft portalType='admin'>
            <Route exact path='/' component={DashboardPage} />
            <PrivateRoute path='/vaccine-list' component={VaccineListPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/vaccination-schedules' component={VaccinationShedulesPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/vaccination-centers' component={VaccinationCentersPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/user-management' component={UserManagementPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/manage-templates' component={ManageTemplates} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/vaccenter-cards' component={VacCenterCards} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/vendor-card-requests' component={VendorCardRequests} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/doctor-list' component={DoctorListPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/doctor-approval' component={DoctorApprovalPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/addnew-doctor' component={AddNewDoc} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/edit-doctor' component={EditDoc} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/doctor-settlements' component={DoctorSettlementsPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/user-engagement' component={UserEngagement} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/consultation-timing' component={ConsultationTiming} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/reports' component={ReportsPage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/tradename-list' component={Tradenamelistpage} portal={PORTAL_TYPE_IMM} />
            <PrivateRoute path='/pending-tradenames' component={ApproveTradename} portal={PORTAL_TYPE_IMM} />
          </PersistentDrawerLeft>
        </Switch>
      </ThemeProvider>
    </Router>
  );
}
