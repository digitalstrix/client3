const parentA = {
    "fullName": "Tharuka Jayalath",
    "addressFull": "\"Senasuma\", Wewalagma, Kurunegala",
    "timeOffset": 0,
    "id": 1413,
    "firstName": "Tharuka",
    "lastName": "Jayalath",
    "idNumber": "555555",
    "email": "tharukajayalath20@gmail.com",
    "contact": "0712687005",
    "country": 193,
    "address1": "\"Senasuma\", Wewalagma",
    "city": "Kurunegala",
    "postalCode": "60506",
    "middleName": "",
    "address2": "",
    "state": "",
    "status": "ACTIVE",
    "managedByThirdParty": false,
    "isAnalogUser": false,
    "updatedAt": "2021-01-09T04:21:49.000Z",
    "createdAt": "2021-01-09T04:21:49.000Z",
    "name": "Tharuka Jayalath"
  };

export const parents = [parentA];