export const selectCountries = state => state.country.countries;
export const selectCountryLoadingStatus = state => state.country.countryLoadingStatus;
export const selectRequestStatus = state => state.requestVaccines.requestStatus;