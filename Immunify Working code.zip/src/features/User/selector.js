export const selectUser = state => state.user.user;
export const selectUserLoadingStatus = state => state.user.userLoadingStatus;