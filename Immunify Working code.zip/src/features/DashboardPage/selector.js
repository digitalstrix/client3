export const selectChartDataLoadingStatus = state => state.dashboard.chartDataLoadingStatus;
export const selectChartData = state => state.dashboard.chartData;
export const selectUser = state => state.user.user;
export const selectCenterStats = state => state.dashboard.centerStats;
export const selectGranularity = state => state.dashboard.granularity;
export const selectStatsLoadingStatus = state => state.dashboard.centerStatsLoadingStatus;