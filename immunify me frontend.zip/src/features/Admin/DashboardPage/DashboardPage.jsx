import React from "react";

const Dashboardpage = () => {
  return (
    <div>
      <h1>Admin Dashboardpage</h1>
    </div>
  );
};

export default Dashboardpage;
