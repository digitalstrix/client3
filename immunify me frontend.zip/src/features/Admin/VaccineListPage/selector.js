export const selectVaccines = state => state.vaccines.vaccines;
export const selectVaccinesLoadingStatus = state => state.vaccines.vaccinesLoadingStatus;
export const selectAddNewVaccineStatus = state => state.vaccines.addNewVaccineStatus;
export const selectUpdateVaccineStatus = state => state.vaccines.updateVaccineStatus;