export const selectConsultationTimes = (state) => state.consultationTimes.consultationTimes;
export const selectCountryLoadingStatus = state => state.country.countryLoadingStatus;
export const selectCountries = state => state.country.countries;