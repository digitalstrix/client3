export const selectAddChildStatus = (state) => state.myChildren.addingChildStatus;
export const selectAddChildError = (state) => state.myChildren.addingChildError;
export const selectParentCountryId = (state) => state.parentProfile.basicProfileData.country;
