export const selectReceivingCallStatus = (state) => state.common.receivingCall;
export const selectCallData = (state) => state.common.callerData;

