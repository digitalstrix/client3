export const selectInputs = state => state.orderDevices.inputs;
export const selectErrors = state => state.orderDevices.errors;
export const selectCreateOrderStatus = state => state.orderDevices.createOrderStatus;