declare module 'react-redux'
declare module 'agora-stream-player'